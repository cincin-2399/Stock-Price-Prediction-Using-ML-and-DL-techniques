from flask import Flask, request, jsonify
import pickle
from sklearn.model_selection import train_test_split
from sklearn.svm import SVR
from sklearn.metrics import roc_auc_score, accuracy_score
from sklearn import preprocessing
from sklearn.metrics import mean_squared_error,mean_absolute_error, mean_absolute_percentage_error
from sklearn import svm
from sklearn.model_selection import GridSearchCV
from sklearn.tree import DecisionTreeRegressor
app = Flask(__name__)
pickled_model = pickle.load(open(r'C:\Users\Admin\Downloads\model.pkl', 'rb'))
@app.route('/calculate', methods=['POST'])
def calculate_close_price():
    data = request.json
    open_price = data['openPrice']
    high_price = data['highPrice']
    low_price = data['lowPrice']
    adj_close = data['adjClose']
    volume = data['volume']
    X_test=[[open_price,high_price,low_price,adj_close,volume,2022,5,12]]
    close_price=pickled_model.predict(X_test)[0]
    # Placeholder calculation logic

    return jsonify({'closePrice': close_price})

if __name__ == '__main__':
    app.run(debug=True)
