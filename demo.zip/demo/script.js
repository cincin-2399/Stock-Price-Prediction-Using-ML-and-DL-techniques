function calculateClosePrice() {
    const openPrice = parseFloat(document.getElementById('openPrice').value);
    const highPrice = parseFloat(document.getElementById('highPrice').value);
    const lowPrice = parseFloat(document.getElementById('lowPrice').value);
    const volume = parseFloat(document.getElementById('volume').value);

    // This is a placeholder for the actual close price calculation logic.
    // For demonstration purposes, we will just average the provided prices.
    const closePrice = (openPrice + highPrice + lowPrice ) / 3+0.17+volume/10000;

    document.getElementById('closePrice').innerText = closePrice.toFixed(4);
}